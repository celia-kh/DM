package com.dataMiningGUI;

public class histo {

}
