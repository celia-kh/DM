package com.dataMiningGUI;

import com.dataMining.Api;
import com.dataMining.Result;
import javafx.application.Application;
import javafx.beans.property.SimpleFloatProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList ;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import java.awt.Desktop;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Observable;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;



import javafx.event.ActionEvent;
import javafx.event.EventHandler;



public class Main extends Application implements
        EventHandler<ActionEvent>{
    @FXML
    public Pane pnl_basic_info, pnl_dataset, pnl_graphs;
    
    @FXML
    private Button remove_btn;
   

   

    @FXML
    private ComboBox<Integer> combo_histo;
    
    @FXML
    private BarChart<?,?> barchart_f;
    
   
    
    
    
    @FXML
    private ComboBox<Integer> att1;

    @FXML
    private ComboBox<Integer> att2;

    @FXML
    private Button button_scatter;
    
    @FXML
    private ScatterChart<?,?> scatter_plot;

    @FXML
    private CategoryAxis x;

    @FXML
    private NumberAxis y;
    
    @FXML
    private Pane histo_pane;

    @FXML
    private Button btn_histo;
    
    @FXML
    public Label lab_box;
    
    @FXML
    public Button btn_basic_info, btn_dataset, btn_graphs;
    @FXML
    public Text txt_num_attr, txt_num_rows, txt_max, txt_min, txt_mean, txt_median, txt_mode, txt_q1, txt_q3, txt_unq_val;
    @FXML
    public TableView<float[]> db_table;

    private boolean dataset_tab_col_init = false;
    private Desktop desktop = Desktop.getDesktop();

    @Override
    public void start(Stage primaryStage) throws Exception{
        Api.init();
        boolean inIntroWindow = true;
        Parent root = FXMLLoader.load(getClass().getResource("intro.fxml"));
        Scene s = new Scene(root);
        ScreenController screenController = new ScreenController(s);
        screenController.addScreen("main", FXMLLoader.load(getClass().getResource( "main.fxml" )));
        if (inIntroWindow) {
            final FileChooser fileChooser = new FileChooser();
            final Button openButton = (Button)  root.lookup("#pick-file-button");
            openButton.setOnAction(
                    new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(final ActionEvent e) {
                            configureFileChooser(fileChooser);
                            File file = fileChooser.showOpenDialog(primaryStage);
                            System.out.println(file.getAbsolutePath());
                            screenController.activate("main");
                            apiCalls(file.getAbsolutePath());
                        /*if (file != null) {
                            openFile(file);
                        }*/
                        }
                    });
        }
        primaryStage.setTitle("Welcome to Data Mining TP!");
        primaryStage.setScene(s);
        primaryStage.show();
    }
    private static void configureFileChooser(final FileChooser fileChooser) {
        fileChooser.setTitle("Select dataset");
        fileChooser.setInitialDirectory(
                new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("TXT", "*.txt")
        );
    }
    
    
    private void openFile(File file) {
        try {
            desktop.open(file);
        } catch (IOException ex) {
            Logger.getLogger(
                    Main.class.getName()).log(
                    Level.SEVERE, null, ex
            );
        }
    }
    public static void main(String[] args) {
        launch(args);
    }

    //************************************Scartter_plot*************************************************************************
   
 
public void sc_plot() 
   {
	 
	      
	int at1=att1.getValue();
	int at2=att2.getValue();
	System.out.println(at1);
	      Series  series = new XYChart.Series();  
	      
	     
	     // series.getData().add(new XYChart.Data (8.0, 12.0)); 
	      //series.getData().add(new XYChart.Data (9.0, 24.0)); 
	      //series.getData().add(new XYChart.Data (1.0, 12.0)); 
	      
	      for(int i=0;i<215;i++)
	      {
	    	  	    	 series.getData().add(new XYChart.Data (Api.data().data()[at1][i],Api.data().data()[at2][i] )); 
	      }
	      

	      
	      
	      
	      scatter_plot.getData().add(series); 
	      
	  
	   
   }
//************************************remove Scartter plot*************************************************************************

public void remove_plot() 
{
	    
	scatter_plot.setAnimated(false);




}
//******************************************************histogramme********************************************

public void histogramme()
{
	int a1=combo_histo.getValue();

	 XYChart.Series series1 = new XYChart.Series();
     series1.setName("Histogram");       
     series1.getData().add(new XYChart.Data("8",50));
     series1.getData().add(new XYChart.Data("9",30));
     barchart_f.getData().addAll(series1);

}

    
    
    @Override
    public void handle(ActionEvent event) {
        if (event.getSource() == btn_basic_info) {
        	//remplire combox histogramme
        	for(int i=0;i<Api.data().data().length;i++)
     	   {combo_histo.getItems().add(i);}
        	
            pnl_basic_info.toFront();
        } else if (event.getSource() == btn_dataset) {
            view_dataset();
            pnl_dataset.toFront();
        } else if (event.getSource() == btn_graphs) {
           
            
           for(int i=0;i<Api.data().data().length;i++)
        	   {att1.getItems().add(i);
           att2.getItems().add(i);}
           
            	 pnl_graphs.toFront();
        }
       
    }

    private void apiCalls(String filename) {
        Result r = Api.readFile(filename);
    }
    
    
    
    
    
    
    
    
    
    
    private void basicInfo() {
        Result r = Api.dimensions();
        txt_num_attr.setText(String.valueOf(r.dim()[0]));
        txt_num_rows.setText(String.valueOf(r.dim()[1]));
        int att = r.dim()[0];
        String s_max = "";
        for (int i = 0; i < att; i++) {
            r = Api.max(i);
            s_max = s_max + "A" + i + ": " + r.content();
            if (i != att-1)
                s_max = s_max + "\t║\t";
        }
        txt_max.setText(s_max);
        /******************************/
        String s_min = "";
        for (int i = 0; i < att; i++) {
            r = Api.min(i);
            s_min = s_min + "A" + i + ": " + r.content();
            if (i != att-1)
                s_min = s_min + "\t║\t";
        }
        txt_min.setText(s_min);
        /******************************/
        String s_mean = "";
        for (int i = 0; i < att; i++) {
            r = Api.mean(i);
            s_mean = s_mean + "A" + i + ": " + r.content();
            if (i != att-1)
                s_mean = s_mean + "\t║\t";
        }
        txt_mean.setText(s_mean);
        /******************************/
        String s_median = "";
        for (int i = 0; i < att; i++) {
            r = Api.median(i);
            s_median = s_median + "A" + i + ": " + r.content();
            if (i != att-1)
                s_median = s_median + "\t║\t";
        }
        txt_median.setText(s_median);
        /******************************/
        String s_mode = "";
        for (int i = 0; i < att; i++) {
            r = Api.mode(i);
            s_mode = s_mode + "A" + i + ": " + r.content();
            if (i != att-1)
                s_mode = s_mode + "\t║\t";
        }
        txt_mode.setText(s_mode);
        /******************************/
        String s_q1 = "";
        for (int i = 0; i < att; i++) {
            r = Api.q1(i);
            s_q1 = s_q1 + "A" + i + ": " + r.content();
            if (i != att-1)
                s_q1 = s_q1 + "\t║\t";
        }
        txt_q1.setText(s_q1);
        /******************************/
        String s_q3 = "";
        for (int i = 0; i < att; i++) {
            r = Api.q3(i);
            s_q3 = s_q3 + "A" + i + ": " + r.content();
            if (i != att-1)
                s_q3 = s_q3 + "\t║\t";
        }
        txt_q3.setText(s_q3);
        /******************************/
        String s_uv = "";

            r = Api.uniqueValues();
        for (int i = 0; i < att; i++) {
            s_uv = s_uv + "A" + i + ": " + r.dynamicData()[i].size();
            if (i != att-1)
                s_uv = s_uv + "\t║\t";
        }
        txt_unq_val.setText(s_uv);
        /******************************/
    }
    private void view_dataset() {
        if (!dataset_tab_col_init) {
            Result r = Api.dimensions();
            TableColumn<float[], Number>[] att  = new TableColumn[r.dim()[0]];
            for (int i = 0; i < r.dim()[0]; i++) {
                att[i] = new TableColumn<>("Attr " + i);
                int columnIndex = i ;
                att[i].setCellValueFactory(cellData -> {
                    float[] row = cellData.getValue();
                    return new SimpleFloatProperty(row[columnIndex]);
                });
                db_table.getColumns().addAll(att[i]);
            }
            dataset_tab_col_init = !dataset_tab_col_init;
            Result data = Api.data();
            float[] j;
            for (int i = 0 ; i < r.dim()[1] ; i++) {
                j = new float[r.dim()[0]];
                for (int k = 0; k < j.length; k++) {
                    j[k] = data.data()[k][i];
                }
                //db_table.getItems().add(data.data()[i]);
                db_table.getItems().add(j);
            }
        }
    }
    private ObservableList<dataRep> getData() {
        Result r = Api.data();

        ObservableList<dataRep> data = FXCollections.observableArrayList();

        float[] j;
        for (int i = 0; i < r.data()[0].length; i++) {
            j = new float[r.data().length];
            for (int k = 0; k < j.length; k++) {
                j[k] = r.data()[k][i];
            }
            data.add(new dataRep(j));
        }
        return data;
    }
    private class dataRep{
        private float[] data;
        public dataRep(float[] data){
            this.data = data;
        }
        public float[] getData() {
            return data;
        }
    }
}
