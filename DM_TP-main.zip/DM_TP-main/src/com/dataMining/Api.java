package com.dataMining;

public class Api {
    private static RushB core;

    public static void init(){
        if (core == null)
            core = new RushB();
    }

    public static Result readFile(String fileName){
        return core.readFile(fileName);
    }

    public static Result data() {
        return core.data();
    }
    public static Result dimensions(){
        return core.dimensions();
    }
    public static Result max(int attributeIndex) {
        return core.max(attributeIndex);
    }
    public static Result min(int attributeIndex) {
        return core.min(attributeIndex);
    }
    public static Result mean(int attributeIndex) {
        return core.mean(attributeIndex);
    }
    public static Result median(int attributeIndex) {
        return core.median(attributeIndex);
    }
    public static Result mode(int attributeIndex) {
        return core.mode(attributeIndex);
    }
    public static Result q1(int attributeIndex) {
        return core.q1(attributeIndex);
    }
    public static Result q3(int attributeIndex) {
        return core.q3(attributeIndex);
    }
    public static Result frequencies() {
        return core.frequencies();
    }
    public static Result uniqueValues() {
        return core.uniqueValues();
    }

    public static void main(String[] args) {
        init();
        Result r = readFile("E:\\study\\2021\\data mining\\Projet datamining 2020-2021\\Thyroid_Dataset.txt");
        Result f = frequencies();
        Result e = max(1);
        System.out.println(e.content());
    }
    
    
    public static void box_plot()
    {
    	
    	
    	
    	
    }
    
    
    
    
    
}